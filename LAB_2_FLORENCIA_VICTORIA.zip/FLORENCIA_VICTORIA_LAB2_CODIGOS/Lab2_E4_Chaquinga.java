// Estudiante: Victoria Joleth Florencia Chaquinga
// NRC: 37712 | Fecha: 29/10/2026
// Ejercicio E4: valida un tamaño impar positivo y dibuja un rombo.

import java.util.Scanner;

public class Lab2_E4_Chaquinga {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n;

        // Solicita al menos una vez y repite si n no es impar positivo.
        do {
            System.out.print("Ingrese un número impar positivo: ");
            n = sc.nextInt();

            if (n <= 0 || n % 2 == 0) {
                System.out.println("Valor inválido. Intente nuevamente.");
            }

        } while (n <= 0 || n % 2 == 0);

        int mitad = n / 2;

        // Parte superior, incluyendo la fila central.
        for (int fila = 0; fila <= mitad; fila++) {

            for (int espacio = 0; espacio < mitad - fila; espacio++) {
                System.out.print(" ");
            }

            for (int asterisco = 0; asterisco < 2 * fila + 1; asterisco++) {
                System.out.print("*");
            }

            System.out.println();
        }

        // Parte inferior: comienza después de la fila central.
        for (int fila = mitad - 1; fila >= 0; fila--) {

            for (int espacio = 0; espacio < mitad - fila; espacio++) {
                System.out.print(" ");
            }

            for (int asterisco = 0; asterisco < 2 * fila + 1; asterisco++) {
                System.out.print("*");
            }

            System.out.println();
        }

        sc.close();
    }
}