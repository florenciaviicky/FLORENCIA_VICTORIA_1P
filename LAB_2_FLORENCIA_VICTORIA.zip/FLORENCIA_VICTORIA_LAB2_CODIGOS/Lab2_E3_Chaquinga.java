// Estudiante: Victoria Joleth Florencia Chaquinga
// NRC: 37712 | Fecha: 29/10/2026
// Ejercicio E3: juego de adivinanza con máximo siete intentos.

import java.util.Random;
import java.util.Scanner;

public class Lab2_E3_Chaquinga {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random azar = new Random();

        int secreto = azar.nextInt(100) + 1;
        int intentos = 0;
        int numero = 0;
        boolean acerto = false;

        // Se ejecuta mientras no acierte y queden intentos.
        do {
            System.out.print("Adivine el número (1 a 100): ");
            numero = sc.nextInt();

            intentos++;

            if (numero < secreto) {
                System.out.println("Más alto");

            } else if (numero > secreto) {
                System.out.println("Más bajo");

            } else {
                acerto = true;
            }

        } while (!acerto && intentos < 7);

        if (acerto) {
            System.out.println("¡Acertó en " + intentos + " intento(s)!");

        } else {
            System.out.println("Se agotaron los intentos. El número era " + secreto);
        }

        sc.close();
    }
}