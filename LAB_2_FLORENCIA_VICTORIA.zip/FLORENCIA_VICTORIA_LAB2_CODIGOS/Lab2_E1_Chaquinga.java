// Estudiante: Victoria Joleth Florencia Chaquinga
// NRC: 37712 | Fecha: 29/10/2026
// Ejercicio E1: imprime la tabla de multiplicar del 1 al 10.

public class Lab2_E1_Chaquinga {
    public static void main(String[] args) {

        // El ciclo externo controla las filas.
        for (int i = 1; i <= 10; i++) {

            // El ciclo interno controla las columnas.
            for (int j = 1; j <= 10; j++) {
                System.out.printf("%4d", i * j);
            }

            System.out.println();
        }
    }
}