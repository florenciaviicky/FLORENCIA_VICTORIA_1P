// Estudiante: Victoria Joleth Florencia Chaquinga
// NRC: 37712 | Fecha: 29/10/2026
// Ejercicio E2: procesa temperaturas hasta ingresar un valor negativo.

import java.util.Scanner;

public class Lab2_E2_Chaquinga {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int contador = 0;
        double suma = 0.0;
        double maximo = 0.0;
        double minimo = 0.0;

        System.out.print("Ingrese temperatura (negativa para terminar): ");
        double lectura = sc.nextDouble();

        // El valor negativo funciona como centinela.
        while (lectura >= 0) {

            if (contador == 0) {
                // La primera lectura válida inicializa máximo y mínimo.
                maximo = lectura;
                minimo = lectura;

            } else {
                if (lectura > maximo) maximo = lectura;
                if (lectura < minimo) minimo = lectura;
            }

            suma += lectura;
            contador++;

            System.out.print("Ingrese temperatura (negativa para terminar): ");
            lectura = sc.nextDouble();
        }

        if (contador == 0) {
            System.out.println("No hubo lecturas válidas.");

        } else {
            double promedio = suma / contador;

            System.out.println("Lecturas: " + contador);
            System.out.printf("Promedio: %.2f%n", promedio);
            System.out.printf("Max: %.2f%n", maximo);
            System.out.printf("Min: %.2f%n", minimo);
        }

        sc.close();
    }
}