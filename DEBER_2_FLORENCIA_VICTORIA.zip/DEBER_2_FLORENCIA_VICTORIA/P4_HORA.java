
import java.util.Scanner;

public class P4_HORA {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int h, m, s;

        System.out.print("Ingrese las horas: ");
        h = sc.nextInt();

        System.out.print("Ingrese los minutos: ");
        m = sc.nextInt();

        System.out.print("Ingrese los segundos: ");
        s = sc.nextInt();

        if (h >= 0 && h <= 23 &&
            m >= 0 && m <= 59 &&
            s >= 0 && s <= 59) {

            s++;

            if (s == 60) {
                s = 0;
                m++;

                if (m == 60) {
                    m = 0;
                    h++;

                    if (h == 24) {
                        h = 0;
                    }
                }
            }

            System.out.printf("Hora siguiente: %02d:%02d:%02d%n", h, m, s);

        } else {
            System.out.println("Error: Hora ingresada no valida.");
        }

        sc.close();
    }
}
