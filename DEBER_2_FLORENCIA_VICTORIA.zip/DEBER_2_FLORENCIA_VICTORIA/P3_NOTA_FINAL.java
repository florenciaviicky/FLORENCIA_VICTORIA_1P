
import java.util.Scanner;

public class P3_NOTA_FINAL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double nota1, nota2, nota3, promedio;

        System.out.print("Ingrese la primera nota: ");
        nota1 = sc.nextDouble();

        System.out.print("Ingrese la segunda nota: ");
        nota2 = sc.nextDouble();

        System.out.print("Ingrese la tercera nota: ");
        nota3 = sc.nextDouble();

        promedio = (nota1 + nota2 + nota3) / 3.0;

        System.out.printf("Promedio final: %.2f%n", promedio);

        if (promedio >= 14.0) {
            System.out.println("<<Aprobado>>");
        } else if (promedio >= 9.0) {
            System.out.println("<<Supletorio>>");
        } else {
            System.out.println("<<Reprobado>>");
        }

        sc.close();
    }
}
