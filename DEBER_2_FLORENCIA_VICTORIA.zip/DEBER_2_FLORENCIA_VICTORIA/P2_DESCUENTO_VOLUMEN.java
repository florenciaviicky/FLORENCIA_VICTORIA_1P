
import java.util.Scanner;

public class P2_DESCUENTO_VOLUMEN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        final double PRECIO_SACO = 8.50;
        final double IVA = 0.15;

        int sacos;
        double subtotal, descuento, porcentaje;
        double valorDescuento, valorIVA, total;

        System.out.print("Ingrese la cantidad de sacos: ");
        sacos = sc.nextInt();

        if (sacos > 0) {
            subtotal = sacos * PRECIO_SACO;

            if (sacos <= 20) {
                porcentaje = 0;
            } else if (sacos <= 50) {
                porcentaje = 0.05;
            } else {
                porcentaje = 0.10;
            }

            valorDescuento = subtotal * porcentaje;
            descuento = subtotal - valorDescuento;
            valorIVA = descuento * IVA;
            total = descuento + valorIVA;

            System.out.printf("Subtotal: $%.2f%n", subtotal);
            System.out.printf("Descuento: $%.2f%n", valorDescuento);
            System.out.printf("IVA: $%.2f%n", valorIVA);
            System.out.printf("Total a pagar: $%.2f%n", total);
        } else {
            System.out.println("Error: Ingrese una cantidad valida.");
        }

        sc.close();
    }
}

