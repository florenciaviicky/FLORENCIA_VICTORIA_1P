
import java.util.Scanner;

public class P1_RESISTENCIA {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double r1, r2, rEq;
        char conexion;

        System.out.print("Ingrese la resistencia 1: ");
        r1 = sc.nextDouble();

        System.out.print("Ingrese la resistencia 2: ");
        r2 = sc.nextDouble();

        if (r1 > 0 && r2 > 0) {
            System.out.print("Tipo de conexion (S = Serie / P = Paralelo): ");
            conexion = sc.next().toUpperCase().charAt(0);

            switch (conexion) {
                case 'S':
                    rEq = r1 + r2;
                    System.out.println("Resistencia equivalente en serie: " + rEq);
                    break;

                case 'P':
                    rEq = (r1 * r2) / (r1 + r2);
                    System.out.println("Resistencia equivalente en paralelo: " + rEq);
                    break;

                default:
                    System.out.println("Error: Tipo de conexion no valido.");
            }
        } else {
            System.out.println("Error: Las resistencias deben ser positivas.");
        }

        sc.close();
    }
}
