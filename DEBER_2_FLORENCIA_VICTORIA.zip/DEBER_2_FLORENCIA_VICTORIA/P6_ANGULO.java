
import java.util.Scanner;

public class P6_ANGULO {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double angulo;

        System.out.print("Ingrese el angulo en grados: ");
        angulo = sc.nextDouble();

        if (angulo < 0) {
            System.out.println("Error: El angulo no puede ser negativo.");

        } else {
            if (angulo > 360) {
                angulo = angulo % 360;
            }

            System.out.println("Angulo evaluado: " + angulo);

            if (angulo > 0 && angulo < 90) {
                System.out.println("Clasificacion: Agudo");

            } else if (angulo == 90) {
                System.out.println("Clasificacion: Recto");

            } else if (angulo > 90 && angulo < 180) {
                System.out.println("Clasificacion: Obtuso");

            } else if (angulo == 180) {
                System.out.println("Clasificacion: Llano");

            } else if (angulo > 180 && angulo < 360) {
                System.out.println("Clasificacion: Concavo");

            } else if (angulo == 360) {
                System.out.println("Clasificacion: Completo");

            } else {
                System.out.println("Angulo nulo: no pertenece a las clasificaciones indicadas.");
            }
        }

        sc.close();
    }
}
